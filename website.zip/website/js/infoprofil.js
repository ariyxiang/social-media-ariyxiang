window.onload = function () {
    // Ambil data dari localStorage
    const savedName = localStorage.getItem('name') || 'Nama Pengguna'; // Nama Pengguna
    const savedUsername = localStorage.getItem('username') || 'username'; // Username
    const savedEmail = localStorage.getItem('email') || 'email@example.com'; // Email
    const savedProfileImg = localStorage.getItem('profilePicture'); // Gambar Profil

    // Mengambil elemen-elemen untuk diperbarui
    const nameElement = document.getElementById('display-name');
    const usernameElement = document.getElementById('display-username');
    const emailElement = document.getElementById('display-email');
    const profileImg = document.querySelector('.profile-pic img'); // Gambar Profil


    // Update nama pengguna, username, dan email
    nameElement.textContent = savedName;
    usernameElement.textContent = savedUsername;
    emailElement.textContent = savedEmail;

    // Update gambar profil jika ada
    if (savedProfileImg) {
        profileImg.src = savedProfileImg;
    } else {
        profileImg.src = 'https://placehold.co/150x150'; // Gambar default
    }
};

// Fungsi kembali ke halaman sebelumnya
function goBack() {
    window.history.back();
}
