window.onload = function () {
  // Ambil data dari localStorage
  const savedName = localStorage.getItem('name') || 'Nama Pengguna';
  const savedUsername = localStorage.getItem('username') || 'username';
  const savedEmail = localStorage.getItem('email') || 'email@example.com';
  const savedProfileImg = localStorage.getItem('profilePicture') || 'https://placehold.co/150x150'; // Gambar default jika tidak ada

  // Mengambil elemen-elemen untuk diperbarui berdasarkan kelas yang sudah ditentukan
  const nameElement = document.querySelector('.info-name span');
  const usernameElement = document.querySelector('.info-username span');
  const emailElement = document.querySelector('.info-email span');
  const profileImg = document.querySelector('.user-profile-image');

  // Update nama pengguna, username, dan email
  nameElement.textContent = savedName;
  usernameElement.textContent = savedUsername;
  emailElement.textContent = savedEmail;

  // Update gambar profil
  profileImg.src = savedProfileImg; // Set gambar profil

// Menambahkan event listener pada tombol Trash
document.querySelector('.mandiri').addEventListener('click', function() {
  // Hapus semua chat
  const chatBody = document.getElementById("chat-body");
  chatBody.innerHTML = ''; // Menghapus semua pesan yang ada

  // Menampilkan "first chat"
  const savedName = localStorage.getItem('name') || 'Nama Pengguna'; // Ambil nama pengguna dari localStorage atau default
  const messageDiv = document.createElement("div");
  messageDiv.classList.add("bot-message");
  messageDiv.innerHTML = `
    <p>Halo ${savedName} 👋<br>Ada yang bisa kami bantu?</p>
    <ul class="question-list">
      <li onclick="sendQuestion('Bagaimana cara melaporkan bug?')">Bagaimana cara melaporkan bug?</li>
      <li onclick="sendQuestion('Apa saja metode pembayaran yang tersedia?')">Apa saja metode pembayaran yang tersedia?</li>
      <li onclick="sendQuestion('Berapa lama waktu pengiriman?')">Berapa lama waktu pengiriman?</li>
    </ul>
  `;
  chatBody.appendChild(messageDiv); // Menambahkan kembali chat pertama
});

  // Menampilkan sapaan dengan nama pengguna dan daftar pertanyaan pertama
  const chatBody = document.getElementById("chat-body");
  const messageDiv = document.createElement("div");
  messageDiv.classList.add("bot-message");
  messageDiv.innerHTML = `
    <p>Halo ${savedName} 👋<br>Ada yang bisa kami bantu?:</p>
    <ul class="question-list">
      <li onclick="sendQuestion('Bagaimana cara melaporkan bug?')">Bagaimana cara melaporkan bug?</li>
      <li onclick="sendQuestion('Apa saja metode pembayaran yang tersedia?')">Apa saja metode pembayaran yang tersedia?</li>
      <li onclick="sendQuestion('Berapa lama waktu pengiriman?')">Berapa lama waktu pengiriman?</li>
    </ul>
  `;
  chatBody.appendChild(messageDiv);

  // Scroll otomatis ke bawah
  chatBody.scrollTop = chatBody.scrollHeight;
};

// Daftar respons otomatis
const responses = {
  "bagaimana cara melakukan pemesanan": "Anda dapat melakukan pemesanan melalui website kami dengan memilih produk, menambahkannya ke keranjang, dan melanjutkan ke pembayaran.",
  "apa saja metode pembayaran yang tersedia": "Kami menerima pembayaran melalui transfer bank, kartu kredit, dan dompet digital seperti GoPay dan OVO.",
  "berapa lama waktu pengiriman": "Waktu pengiriman tergantung lokasi Anda, biasanya 2-5 hari kerja.",
  "kamu sudah makan": "Tidak.",
  "bagaimana cara melaporkan bug": "Kamu bisa meng klik link di bawah ini<br>https://forms.gle/2DV3uXw2r1VavPD59",
};

// Fungsi untuk mengirim pesan dari daftar pertanyaan
function sendQuestion(question) {
  addMessage("user", question);
  respondToMessage(question);
}

// Fungsi untuk menambahkan pesan ke chat dengan animasi
function addMessage(sender, message) {
  const chatBody = document.getElementById("chat-body");
  const messageDiv = document.createElement("div");

// Jika pengirimnya bot, ubah URL menjadi tautan yang bisa diklik
      if (sender === "bot") {
        message = message.replace(
          /(https?:\/\/[^\s]+)/g, 
          '<a href="$1" class="chat-link">$1</a>'
        );
      }
      
  messageDiv.classList.add(sender === "user" ? "user-message" : "bot-message");
  messageDiv.innerHTML = `<p>${message}</p>`;
  chatBody.appendChild(messageDiv);
      
  // Scroll otomatis ke bawah
  chatBody.scrollTop = chatBody.scrollHeight;
}

// Fungsi untuk menambahkan indikator mengetik
function showTypingIndicator() {
  const chatBody = document.getElementById("chat-body");
  const typingDiv = document.createElement("div");

  typingDiv.classList.add("typing-indicator");
  typingDiv.setAttribute("id", "typing-indicator");
  typingDiv.innerHTML = `
    <span class="typing-dot"></span>
    <span class="typing-dot"></span>
    <span class="typing-dot"></span>
  `;

  chatBody.appendChild(typingDiv);
  chatBody.scrollTop = chatBody.scrollHeight;
}

// Fungsi untuk menghapus indikator mengetik
function removeTypingIndicator() {
  const typingIndicator = document.getElementById("typing-indicator");
  if (typingIndicator) {
    typingIndicator.remove();
  }
}

// Fungsi untuk merespons pesan dengan indikator mengetik
function respondToMessage(message) {
  const cleanedMessage = cleanMessage(message);
  const response = responses[cleanedMessage] || "Maaf, saya tidak mengerti pertanyaan Anda.";

  // Tampilkan indikator mengetik
  showTypingIndicator();

  // Simulasi jeda mengetik sebelum respons bot muncul
  setTimeout(() => {
    removeTypingIndicator(); // Hapus indikator mengetik
    addMessage("bot", response); // Tampilkan respons bot
  }, 1500); // Simulasi bot "mengetik" selama 1.5 detik
}

// Fungsi untuk membersihkan dan menormalisasi pesan
function cleanMessage(message) {
  return message.toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
}

// Fungsi untuk menangani pesan pengguna
function sendUserMessage() {
  const inputField = document.getElementById("user-input");
  const userMessage = inputField.value.trim();

  if (userMessage !== "") {
    addMessage("user", userMessage); // Tampilkan pesan pengguna
    respondToMessage(userMessage); // Respon dari bot
    inputField.value = ""; // Kosongkan input setelah pesan dikirim
  }
}

// Fungsi untuk menangani input dengan tombol Enter
function handleKeyPress(event) {
  if (event.key === "Enter") {
    sendUserMessage();
  }
}

// Fungsi untuk menampilkan/menghilangkan sidebar
function toggleSidebar() {
  const sidebar = document.getElementById("sidebar");
  sidebar.classList.toggle("active");

  // Tambahkan/deteksi klik di luar sidebar
  if (sidebar.classList.contains("active")) {
    document.addEventListener("click", closeSidebarOnClickOutside);
  } else {
    document.removeEventListener("click", closeSidebarOnClickOutside);
  }
}

// Fungsi untuk menutup sidebar saat klik di luar
function closeSidebarOnClickOutside(event) {
  const sidebar = document.getElementById("sidebar");
  const menuIcon = document.querySelector(".menu-icon");

  // Jika klik bukan di sidebar atau ikon menu
  if (!sidebar.contains(event.target) && !menuIcon.contains(event.target)) {
    sidebar.classList.remove("active");
    document.removeEventListener("click", closeSidebarOnClickOutside); // Hapus event listener
  }
}

function goBack() {
  window.history.back(); // Kembali ke halaman sebelumnya di browser
}

