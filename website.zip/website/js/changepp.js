window.onload = function () {
    // Ambil data dari localStorage
    const savedUsername = localStorage.getItem('username') || 'Username'; // Username
    const savedName = localStorage.getItem('name') || 'Nama Pengguna'; // Nama Lengkap (bisa disesuaikan)
    const savedEmail = localStorage.getItem('email') || 'email@example.com'; // Email
    const savedProfileImg = localStorage.getItem('profilePicture'); // Gambar profil

    // Update profil dengan data yang sudah disimpan
    const profileName = document.getElementById('profile-name'); // Mengambil elemen untuk nama lengkap
    const profileUsername = document.getElementById('profile-username'); // Mengambil elemen untuk username
    const profileEmail = document.getElementById('profile-email'); // Mengambil elemen untuk email
    const profileImg = document.getElementById('profile-img'); // Mengambil elemen untuk gambar profil

    // Mengupdate nama lengkap dan username di tampilan
    profileName.textContent = savedName; // Menampilkan nama lengkap
    profileUsername.textContent = savedUsername; // Menampilkan username
    profileEmail.textContent = savedEmail; // Menampilkan email

    // Update gambar profil
    if (savedProfileImg) {
        profileImg.src = savedProfileImg; // Set gambar profil jika ada
    } else {
        profileImg.src = ''; // Gambar default jika tidak ada gambar yang disimpan
    }
};

// Fungsi untuk memicu animasi keluar pada elemen tertentu
function triggerExitAnimation() {
    const body = document.body;
    const container = document.querySelector('.container');
    const header = document.querySelector('.header');
    const profile = document.querySelector('.profile');
    const menuItems = document.querySelectorAll('.menu-item');
    const footer = document.querySelector('.footer');

    // Pastikan elemen ada sebelum menambahkan kelas animasi
    if (body) body.classList.add('fade-out');
    if (container) container.classList.add('fade-out');
    if (header) header.classList.add('fade-out');
    if (profile) profile.classList.add('fade-out');
    if (menuItems.length) menuItems.forEach(item => item.classList.add('fade-out'));
    if (footer) footer.classList.add('fade-out');
}

// Pastikan elemen exit-button ada sebelum menambahkan event listener
const exitButton = document.querySelector('.back-arrow');
if (exitButton) {
    exitButton.addEventListener('click', function() {
        triggerExitAnimation(); // Menambahkan animasi keluar sebelum pergi ke halaman sebelumnya
        goBack(); // Memanggil fungsi goBack setelah animasi dimulai
    });
}

function goBack() {
    window.history.back(); // Kembali ke halaman sebelumnya di browser
}