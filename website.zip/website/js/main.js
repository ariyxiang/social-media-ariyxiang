document.addEventListener("DOMContentLoaded", function () {
    // Ambil data username, email, dan foto profil dari localStorage
    const name = localStorage.getItem('name');
    const username = localStorage.getItem('username');
    const email = localStorage.getItem('email');
    const profilePicture = localStorage.getItem('profilePicture');

    if (name && username && email && profilePicture) {
        const sidebarName = document.querySelector('.sidebar__info h3');
        const sidebarUsername = document.querySelector('.sidebar__info h5');
        const sidebarEmail = document.querySelector('.sidebar__info span');
        const sidebarImg = document.querySelector('.sidebar__img img');

        sidebarName.textContent = name;
        sidebarUsername.textContent = username;
        sidebarEmail.textContent = email;
        sidebarImg.src = profilePicture;
    }

    /*=============== SHOW SIDEBAR ===============*/
    const showSidebar = (toggleId, sidebarId, headerId, mainId) => {
        const toggle = document.getElementById(toggleId),
            sidebar = document.getElementById(sidebarId),
            header = document.getElementById(headerId),
            main = document.getElementById(mainId);

        if (toggle && sidebar && header && main) {
            toggle.addEventListener('click', () => {
                sidebar.classList.toggle('show-sidebar');
                header.classList.toggle('left-pd');
                main.classList.toggle('left-pd');
            });
        }
    };
    showSidebar('header-toggle', 'sidebar', 'header', 'main');

    /*=============== LINK ACTIVE ===============*/
    const sidebarLink = document.querySelectorAll('.sidebar__list a');

    function linkColor() {
        sidebarLink.forEach(l => l.classList.remove('active-link'));
        this.classList.add('active-link');
    }

    sidebarLink.forEach(l => l.addEventListener('click', linkColor));

    /*=============== DARK LIGHT THEME (Default Dark) ===============*/
    const themeButton = document.getElementById('theme-button');
    const darkTheme = 'dark-theme';
    const iconTheme = 'ri-sun-fill';

    let selectedTheme = localStorage.getItem('selected-theme');
    let selectedIcon = localStorage.getItem('selected-icon');

    // Jika tidak ada data di localStorage, tema default adalah dark
    if (!selectedTheme) {
        selectedTheme = 'dark';
        selectedIcon = 'ri-moon-clear-fill';
        localStorage.setItem('selected-theme', selectedTheme);
        localStorage.setItem('selected-icon', selectedIcon);
    }

    // Terapkan tema berdasarkan localStorage
    document.body.classList[selectedTheme === 'dark' ? 'add' : 'remove'](darkTheme);
    themeButton.classList[selectedIcon === 'ri-moon-clear-fill' ? 'add' : 'remove'](iconTheme);

    const getCurrentTheme = () => document.body.classList.contains(darkTheme) ? 'dark' : 'light';
    const getCurrentIcon = () => themeButton.classList.contains(iconTheme) ? 'ri-moon-clear-fill' : 'ri-sun-fill';

    themeButton.addEventListener('click', () => {
        document.body.classList.toggle(darkTheme);
        themeButton.classList.toggle(iconTheme);
        localStorage.setItem('selected-theme', getCurrentTheme());
        localStorage.setItem('selected-icon', getCurrentIcon());
    });

    /*=============== PRODUCT PURCHASE NOTIFICATION ===============*/
    const purchaseButtons = document.querySelectorAll('.product__button');

    purchaseButtons.forEach(button => {
        button.addEventListener('click', () => {
            const productName = button.getAttribute('data-name');
            const productPrice = button.getAttribute('data-price');

            showPaymentNotification(productName, productPrice);
        });
    });

    function showPaymentNotification(productName, productPrice) {
        const notification = document.createElement('div');
        notification.classList.add('payment-notification');
        notification.innerHTML = `
            <p>Berhasil Membeli <strong>${productName}</strong> Seharga Rp${productPrice.replace(/\B(?=(\d{3})+(?!\d))/g, ".")}.</p>
            <button class="notification-close" onclick="closeNotification()">X</button>
        `;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 5000);
    }

    window.closeNotification = function () {
        const notification = document.querySelector('.payment-notification');
        if (notification) {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    };
});
