window.onload = function () {
    // Memeriksa apakah pengguna sudah login
    const email = localStorage.getItem('email');
    const password = localStorage.getItem('password');

    if (!email || !password) {
        // Jika tidak ada email atau password, redirect ke halaman login
        window.location.href = 'log.html';
    }

    // Mengambil data nama dan foto profil dari localStorage
    const name = localStorage.getItem('name');
    const profilePicture = localStorage.getItem('profilePicture'); // Ambil foto profil dari localStorage

    // Jika ada data nama dan foto profil, tampilkan di form
    if (name) {
        document.getElementById('username').value = name; // Isi input nama pengguna
    }
};

// Fungsi untuk menangani penyimpanan perubahan profil
document.getElementById('save-button').addEventListener('click', function () {
    const name = document.getElementById('username').value; // Ambil nama pengguna dari input
    const profilePicture = document.getElementById('profile-picture').files[0];

    if (!name) {
        showNotification('Nama Pengguna tidak boleh kosong !', 'error');
        return;
    }

    // Simpan Nama Pengguna ke localStorage
    localStorage.setItem('name', name);

    if (profilePicture) {
        const reader = new FileReader();
        reader.onloadend = function () {
            localStorage.setItem('profilePicture', reader.result); // Simpan foto profil ke localStorage
            showNotification('Berhasil membuat akun', 'success');
            window.location.href = 'home.html'; // Arahkan ke halaman home setelah penyimpanan
        };
        reader.readAsDataURL(profilePicture); // Baca file sebagai Data URL
    } else {
        showNotification('Berhasil membuat akun', 'success');
        window.location.href = 'home.html'; // Arahkan ke halaman home jika foto tidak diubah
    }

document.getElementById('username').value = '';  // Mengosongkan input nama pengguna
});

// Fungsi untuk menampilkan notifikasi
function showNotification(message, type) {
    var notification = document.getElementById('notification');
    var notificationMessage = document.getElementById('notification-message');
    
    notificationMessage.textContent = message;
    
    notification.classList.add(type);
    notification.style.display = 'block';
    
    setTimeout(function() {
        notification.style.opacity = '0';
    }, 1000);
    
    setTimeout(function() {
        notification.style.display = 'none';
        notification.style.opacity = '1';
        notification.classList.remove(type);
    }, 1500);
}
