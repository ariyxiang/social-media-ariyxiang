// Fungsi untuk menangani registrasi
document.getElementById("form-registrasi")?.addEventListener("submit", function(event) {
    event.preventDefault();

    let username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Validasi jika ada field yang kosong
    if (!username || !email || !password) {
        showNotification("Semua field harus diisi!", "error");
        return;
    }

    // Validasi username: hanya huruf kecil, garis bawah dan tanpa spasi
    const usernameRegex = /^[a-z_]+$/;
    if (!usernameRegex.test(username)) {
        showNotification("Username hanya boleh menggunakan huruf kecil, garis bawah (_), dan tanpa spasi.", "error");
        return;
    }

    const emailRegex = /^[a-z@.]+$/;
    if (!emailRegex.test(email)) {
        showNotification("Email hanya boleh menggunakan huruf kecil, garis bawah (_), dan tanpa spasi.", "error");
        return;
    }

    // Simpan data ke localStorage
    localStorage.setItem("username", username);
    localStorage.setItem("email", email);
    localStorage.setItem("password", password);

    // Tampilkan notifikasi berhasil registrasi
    showNotification("Registrasi berhasil! Silakan login.", "success");

    // Arahkan ke halaman login setelah registrasi
    setTimeout(function() {
        window.location.href = "log.html"; // Pengalihan ke login.html setelah 2 detik
    }, 2000);  // Delay agar notifikasi sempat terlihat
});

// Fungsi untuk menangani login
document.getElementById('form-login')?.addEventListener('submit', function(event) {
    event.preventDefault();

    // Ambil data input login
    var username = document.getElementById('login-username').value;
    var password = document.getElementById('login-password').value;

    // Validasi jika ada field yang kosong
    if (!username || !password) {
        showNotification("Harap di isi terlebih dahulu !", "error");
        return;
    }

    // Ambil data dari localStorage
    var storedUsername = localStorage.getItem('username');
    var storedEmail = localStorage.getItem('email'); // Tambahkan email
    var storedPassword = localStorage.getItem('password');

    // Validasi login dengan username atau email
    if ((username === storedUsername || username === storedEmail) && password === storedPassword) {
        // Login berhasil, arahkan ke halaman profil
        window.location.href = 'profil.html';
    } else {
        // Login gagal
        showNotification('Username, Email, atau Password salah', 'error');
    }
});

// Fungsi untuk menampilkan notifikasi
function showNotification(message, type) {
    var notification = document.getElementById('notification');
    var notificationMessage = document.getElementById('notification-message');
    
    notificationMessage.textContent = message;
    
    notification.classList.add(type);
    notification.style.display = 'block';
    
    setTimeout(function() {
        notification.style.opacity = '0';
    }, 1000);
    
    setTimeout(function() {
        notification.style.display = 'none';
        notification.style.opacity = '1';
        notification.classList.remove(type);
    }, 1500);
}
